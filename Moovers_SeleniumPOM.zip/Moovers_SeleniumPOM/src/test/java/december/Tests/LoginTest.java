package december.Tests;

import java.io.FileInputStream;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;



import december.generic.Screenshot;
import december.Pom.LoginPOM;
import december.Utility.Driver;
import december.Utility.DriverNames;
import december.Utility.DriverFactory;

public class LoginTest {

	private WebDriver driver;
	private String baseUrl;
	private LoginPOM loginPOM;
	private Screenshot ScreenShot;



	@Before
	public void setUp() throws Exception {
		driver = DriverFactory.getDriver(DriverNames.CHROME);
		loginPOM = new LoginPOM(driver);
		ScreenShot = new Screenshot(driver);
		baseUrl = "https://opensource-demo.orangehrmlive.com/"; 
		// open the browser
		driver.get(baseUrl);
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(5000);
		driver.quit();
	}

	@Test
	public void loginPassTest() {
		loginPOM.sendUserName("admin");
		loginPOM.sendPassword("admin123");
		loginPOM.clickLoginBtn();
	}

}
